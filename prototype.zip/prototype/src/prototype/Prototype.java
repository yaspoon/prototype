/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author brock
 */
public class Prototype {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainWindow theWindow = new MainWindow();
        theWindow.setTitle("OPIG PDF Collaboration Prototype 1");
        theWindow.setVisible(true);
    }
}
